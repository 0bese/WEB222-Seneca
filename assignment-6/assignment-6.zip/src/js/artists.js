/**
 * artists.js
 *
 * The app's list of Artists
 */

window.artists = [
  /* TODO */
  {
    artistId: "AID-0233",
    name: "Sarkodie",
    urls: [
      {
        url: "https://instagram.com/sarkodie?igshid=MzRlODBiNWFlZA==",
        name: "Instagram",
      },
      {
        url: "https://x.com/sarkodie?s=21&t=YedajTwsDR-XWX4wc3lc0w",
        name: "X",
      },
    ],
  },
  {
    artistId: "AID-0331",
    name: "BlackSherif",
    urls: [
      {
        url: "https://instagram.com/blacksherif_?igshid=MzRlODBiNWFlZA==",
        name: "Instagram",
      },
      {
        url: "https://x.com/blacksherif_?s=21&t=YedajTwsDR-XWX4wc3lc0w",
        name: "X",
      },
    ],
  },
  {
    artistId: "AID-0635",
    name: "Kwesi Arthur",
    urls: [
      {
        url: "https://instagram.com/kwesiarthur_?igshid=MzRlODBiNWFlZA==",
        name: "Instagram",
      },
      {
        url: "https://x.com/kwesiarthur_?s=21&t=YedajTwsDR-XWX4wc3lc0w",
        name: "X",
      },
    ],
  },
];
